import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Entrada:");

        String linha = null;

        while(linha != "FIM"){
            linha = sc.nextLine();
            isUpper(linha);
        }


        sc.close();
    }

    public static int isUpper(String linha){
        int cont = 0;
        for (int i = 0; i < linha.length(); i++) {
            char letra = linha.charAt(i);
            if(letra )
        }

        if(linha.char)

        return palavra;
    }
}