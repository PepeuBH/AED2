public class Palavra {

}
