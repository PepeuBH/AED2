public class Funcionario {
    public double salario;
    public String nome;

}
