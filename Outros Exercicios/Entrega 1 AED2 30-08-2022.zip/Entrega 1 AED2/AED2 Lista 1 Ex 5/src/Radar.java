public class Radar {
    public double velocidade;
    public int cont = 0;

    public double totalArrecadado(){
        return cont * 150;
    }


}
